import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lib-dashboard',
  templateUrl: './lib-dashboard.component.html',
  styleUrls: ['./lib-dashboard.component.css']
})
export class LibDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
