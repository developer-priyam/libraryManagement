export interface Book {
    id: number;
    name: string;
    availableCopies: number;
    totalCopies: number;
}