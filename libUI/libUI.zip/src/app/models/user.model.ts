export interface User {
    id: number;
	name: string;
    issuedBooks: number[];
}