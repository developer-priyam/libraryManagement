import { ConvertToNamePipe } from './convert-to-name.pipe';

describe('ConvertToNamePipe', () => {
  it('create an instance', () => {
    const pipe = new ConvertToNamePipe();
    expect(pipe).toBeTruthy();
  });
});
